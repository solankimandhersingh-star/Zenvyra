import { useEffect, useMemo, useState } from 'react';

import './ModulePages.css';

import {
  getInvoices,
} from '../services/invoiceService';

import type {
  InvoiceResponse,
  InvoiceStatus,
} from '../types/invoice';

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
  }).format(amount);
};

const formatDate = (date?: string | null) => {
  if (!date) {
    return '-';
  }

  return new Intl.DateTimeFormat('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(new Date(date));
};

const statusClass = (status: InvoiceStatus) => {
  return `module-status ${status
    .toLowerCase()
    .replaceAll('_', '-')}`;
};

export default function Invoices() {
  const [invoices, setInvoices] = useState<InvoiceResponse[]>([]);
  const [search, setSearch] = useState('');

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const loadInvoices = async () => {
    try {
      setLoading(true);
      setError('');

      const data = await getInvoices();

      setInvoices(data);
    } catch (err: any) {
      console.error('Failed to load invoices:', err);

      const message =
        err?.response?.data?.message ||
        err?.response?.data?.error ||
        'Unable to load invoices.';

      setError(message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadInvoices();
  }, []);

  const filteredInvoices = useMemo(() => {
    const value = search.trim().toLowerCase();

    if (!value) {
      return invoices;
    }

    return invoices.filter((invoice) => {
      return (
        invoice.invoiceNumber.toLowerCase().includes(value) ||
        invoice.buyerName.toLowerCase().includes(value) ||
        invoice.status.toLowerCase().includes(value)
      );
    });
  }, [invoices, search]);

  const openInvoice = (invoiceId: string) => {
    window.open(
      `/invoices/${invoiceId}`,
      '_blank',
      'noopener,noreferrer'
    );
  };

  const openCreateInvoice = () => {
    window.open(
      '/invoices/create',
      '_blank',
      'noopener,noreferrer'
    );
  };

  return (
    <div className="module-page">

      {/* HEADER */}
      <div className="module-header">
        <div>
          <span className="module-eyebrow">
            BILLING
          </span>

          <h1>Invoices</h1>

          <p>
            Create, manage and track organization invoices.
          </p>
        </div>

        <button
          type="button"
          className="module-primary"
          onClick={openCreateInvoice}
        >
          + Create Invoice
        </button>
      </div>

      {/* ERROR */}
      {error && (
        <div
          className="module-card"
          style={{
            marginBottom: '20px',
            borderColor: '#fecdca',
            background: '#fffafa',
          }}
        >
          <strong
            style={{
              color: '#b42318',
            }}
          >
            Unable to load invoices
          </strong>

          <p
            style={{
              margin: '6px 0 12px',
              color: '#912018',
            }}
          >
            {error}
          </p>

          <button
            type="button"
            className="module-primary"
            onClick={loadInvoices}
          >
            Try Again
          </button>
        </div>
      )}

      {/* INVOICE LIST */}
      <div className="module-card">

        <div className="module-toolbar">

          <div>
            <strong>Invoices</strong>

            <span>
              {loading
                ? 'Loading...'
                : `${invoices.length} records`}
            </span>
          </div>

          <input
            type="text"
            placeholder="Search invoice..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />

        </div>

        {loading ? (
          <div
            style={{
              padding: '60px 20px',
              textAlign: 'center',
              color: '#667085',
            }}
          >
            Loading invoices...
          </div>
        ) : filteredInvoices.length === 0 ? (

          <div
            style={{
              padding: '60px 20px',
              textAlign: 'center',
              color: '#667085',
            }}
          >
            {invoices.length === 0
              ? 'No invoices found.'
              : 'No invoices match your search.'}
          </div>

        ) : (

          <div className="module-table-wrap">

            <table className="module-table">

              <thead>
                <tr>
                  <th>Invoice</th>
                  <th>Customer</th>
                  <th>Date</th>
                  <th>Due Date</th>
                  <th>Amount</th>
                  <th>Status</th>
                  <th>Action</th>
                </tr>
              </thead>

              <tbody>

                {filteredInvoices.map(
                  (invoice) => (

                    <tr key={invoice.id}>

                      <td>
                        <strong>
                          {invoice.invoiceNumber}
                        </strong>
                      </td>

                      <td>
                        {invoice.buyerName}
                      </td>

                      <td>
                        {formatDate(
                          invoice.invoiceDate
                        )}
                      </td>

                      <td>
                        {formatDate(
                          invoice.dueDate
                        )}
                      </td>

                      <td>
                        {formatCurrency(
                          invoice.grandTotal
                        )}
                      </td>

                      <td>
                        <span
                          className={statusClass(
                            invoice.status
                          )}
                        >
                          {invoice.status.replaceAll(
                            '_',
                            ' '
                          )}
                        </span>
                      </td>

                      <td>
                        <button
                          type="button"
                          className="module-secondary"
                          onClick={() =>
                            openInvoice(
                              invoice.id
                            )
                          }
                        >
                          View
                        </button>
                      </td>

                    </tr>

                  )
                )}

              </tbody>

            </table>

          </div>

        )}

        <div className="module-note">
          Invoice data is loaded from the Zenvyra
          Invoice Service.
        </div>

      </div>

    </div>
  );
}