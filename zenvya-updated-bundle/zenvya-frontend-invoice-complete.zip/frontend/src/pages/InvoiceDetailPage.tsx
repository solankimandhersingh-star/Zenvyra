import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { getInvoiceById } from '../services/invoiceService';
import type { InvoiceResponse } from '../types/invoice';
import './InvoiceDetailPage.css';

const money = (value: number) => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(value);
const date = (value?: string | null) => value ? new Intl.DateTimeFormat('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }).format(new Date(value)) : '—';

export default function InvoiceDetailPage() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [invoice, setInvoice] = useState<InvoiceResponse | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (!id) return;
    getInvoiceById(id)
      .then(setInvoice)
      .catch((e: any) => setError(e?.response?.data?.message || 'Unable to load invoice.'))
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div className="invoice-detail-state">Loading invoice...</div>;
  if (error || !invoice) return <div className="invoice-detail-state"><h2>Unable to open invoice</h2><p>{error || 'Invoice not found.'}</p><button onClick={() => navigate(-1)}>Go Back</button></div>;

  const isWorkspace = window.location.pathname.startsWith('/workspace/');
  const workspaceMatch = window.location.pathname.match(/^\/workspace\/([^/]+)/);
  const backPath = isWorkspace && workspaceMatch?.[1] ? `/workspace/${workspaceMatch[1]}/invoices` : '/invoices';

  return (
    <div className="invoice-detail-page">
      <div className="invoice-detail-toolbar no-print">
        <button className="invoice-toolbar-secondary" onClick={() => navigate(backPath)}>← Invoices</button>
        <div><button className="invoice-toolbar-secondary" onClick={() => window.print()}>Print / Save PDF</button></div>
      </div>

      <article className="tax-invoice">
        <header className="tax-invoice-header">
          <div className="seller-block">
            <div className="seller-mark">Z</div>
            <div><h1>{invoice.sellerName}</h1><p>{invoice.sellerAddress || '—'}</p>{invoice.sellerState && <p>{invoice.sellerState}{invoice.sellerStateCode ? ` · ${invoice.sellerStateCode}` : ''}</p>}<p>{invoice.sellerEmail || ''}{invoice.sellerMobile ? ` · ${invoice.sellerMobile}` : ''}</p>{invoice.sellerGstin && <strong>GSTIN: {invoice.sellerGstin}</strong>}</div>
          </div>
          <div className="tax-title"><span>TAX INVOICE</span><strong>{invoice.invoiceNumber}</strong><small>Date: {date(invoice.invoiceDate)}</small>{invoice.dueDate && <small>Due: {date(invoice.dueDate)}</small>}<em className={`detail-status ${invoice.status.toLowerCase().replaceAll('_', '-')}`}>{invoice.status.replaceAll('_', ' ')}</em></div>
        </header>

        <section className="invoice-parties">
          <div><span className="party-label">BILL TO</span><h3>{invoice.buyerName}</h3><p>{invoice.buyerAddress || '—'}</p>{invoice.buyerState && <p>{invoice.buyerState}{invoice.buyerStateCode ? ` · ${invoice.buyerStateCode}` : ''}</p>}{invoice.buyerEmail && <p>{invoice.buyerEmail}</p>}{invoice.buyerMobile && <p>{invoice.buyerMobile}</p>}{invoice.buyerGstin && <strong>GSTIN: {invoice.buyerGstin}</strong>}</div>
          <div><span className="party-label">SHIP TO</span><h3>{invoice.shippingName || invoice.buyerName}</h3><p>{invoice.shippingAddress || invoice.buyerAddress || '—'}</p>{invoice.shippingState && <p>{invoice.shippingState}{invoice.shippingStateCode ? ` · ${invoice.shippingStateCode}` : ''}</p>}</div>
          <div><span className="party-label">SUPPLY</span><h3>{invoice.placeOfSupply || '—'}</h3><p>Code: {invoice.placeOfSupplyCode || '—'}</p><p>Reverse Charge: {invoice.reverseCharge ? 'Yes' : 'No'}</p></div>
        </section>

        <section className="invoice-items-section">
          <table className="tax-items"><thead><tr><th>#</th><th>Item / Description</th><th>HSN/SAC</th><th>Qty</th><th>Rate</th><th>Taxable</th><th>GST</th><th>Total</th></tr></thead><tbody>{invoice.items.map((item) => <tr key={item.id}><td>{item.lineNumber}</td><td><strong>{item.productName}</strong>{item.description && <small>{item.description}</small>}</td><td>{item.hsnSac || '—'}</td><td>{item.quantity} {item.unit}</td><td>{money(item.unitPrice)}</td><td>{money(item.taxableValue)}</td><td>{item.taxRate}%</td><td><strong>{money(item.totalAmount)}</strong></td></tr>)}</tbody></table>
        </section>

        <section className="invoice-bottom-grid">
          <div className="payment-panel"><h3>Payment Information</h3>{invoice.bankName && <p><strong>Bank:</strong> {invoice.bankName}</p>}{invoice.accountNumber && <p><strong>Account:</strong> {invoice.accountNumber}</p>}{invoice.ifscCode && <p><strong>IFSC:</strong> {invoice.ifscCode}</p>}{invoice.accountType && <p><strong>Type:</strong> {invoice.accountType}</p>}{invoice.bankBranch && <p><strong>Branch:</strong> {invoice.bankBranch}</p>}<h3 className="terms-title">Terms & Conditions</h3><p className="terms-text">{invoice.termsAndConditions || '—'}</p></div>
          <div className="totals-panel"><div><span>Subtotal</span><strong>{money(invoice.subtotal)}</strong></div><div><span>Discount</span><strong>{money(invoice.discountAmount)}</strong></div><div><span>Taxable Amount</span><strong>{money(invoice.taxableAmount)}</strong></div>{invoice.cgstAmount > 0 && <div><span>CGST</span><strong>{money(invoice.cgstAmount)}</strong></div>}{invoice.sgstAmount > 0 && <div><span>SGST</span><strong>{money(invoice.sgstAmount)}</strong></div>}{invoice.igstAmount > 0 && <div><span>IGST</span><strong>{money(invoice.igstAmount)}</strong></div>}<div><span>Round Off</span><strong>{money(invoice.roundOff)}</strong></div><div className="grand-total"><span>Grand Total</span><strong>{money(invoice.grandTotal)}</strong></div>{invoice.amountInWords && <p className="amount-words"><strong>Amount in words:</strong> {invoice.amountInWords}</p>}</div>
        </section>

        <footer className="tax-invoice-footer"><div></div><div className="signature"><div className="signature-line"></div><strong>{invoice.authorizedSignatoryName || 'Authorized Signatory'}</strong><span>For {invoice.sellerName}</span></div><p>Invoice generated &amp; securely managed with Zenvyra</p></footer>
      </article>
    </div>
  );
}
