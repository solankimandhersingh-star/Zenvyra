import { useEffect, useMemo, useState } from 'react';
import { useLocation, useNavigate, useParams } from 'react-router-dom';
import { getCustomers, type Customer } from '../services/customerService';
import { createInvoice } from '../services/invoiceService';
import { getProducts, type Product } from '../services/productService';
import { getStoredUser } from '../services/authService';
import type { CreateInvoiceRequest, InvoiceTaxTreatment } from '../types/invoice';
import './InvoiceCreatePage.css';

interface LineDraft {
  productId: string;
  quantity: string;
  discountAmount: string;
  taxTreatment: InvoiceTaxTreatment;
  taxRate: string;
}

const today = () => new Date().toISOString().slice(0, 10);
const addDays = (days: number) => {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
};

const emptyLine = (): LineDraft => ({
  productId: '',
  quantity: '1',
  discountAmount: '0',
  taxTreatment: 'GST_EXTRA',
  taxRate: '',
});

const money = (value: number) =>
  new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
  }).format(value);

export default function InvoiceCreatePage() {
  const navigate = useNavigate();
  const location = useLocation();
  const { id: workspaceId } = useParams<{ id: string }>();
  const user = getStoredUser();
  const organizationId = workspaceId || user?.organizationId || '';
  const inWorkspace = location.pathname.startsWith('/workspace/');
  const backPath = inWorkspace && workspaceId
    ? `/workspace/${workspaceId}/invoices`
    : '/invoices';

  const [customers, setCustomers] = useState<Customer[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [invoiceDate, setInvoiceDate] = useState(today());
  const [dueDate, setDueDate] = useState(addDays(15));
  const [customerId, setCustomerId] = useState('');
  const [placeOfSupply, setPlaceOfSupply] = useState('');
  const [placeOfSupplyCode, setPlaceOfSupplyCode] = useState('');
  const [shippingName, setShippingName] = useState('');
  const [shippingAddress, setShippingAddress] = useState('');
  const [shippingState, setShippingState] = useState('');
  const [shippingStateCode, setShippingStateCode] = useState('');
  const [reverseCharge, setReverseCharge] = useState(false);
  const [bankName, setBankName] = useState('');
  const [accountNumber, setAccountNumber] = useState('');
  const [ifscCode, setIfscCode] = useState('');
  const [accountType, setAccountType] = useState('');
  const [bankBranch, setBankBranch] = useState('');
  const [terms, setTerms] = useState('Payment due as per the invoice due date.');
  const [signatory, setSignatory] = useState('');
  const [lines, setLines] = useState<LineDraft[]>([emptyLine()]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    const load = async () => {
      if (!organizationId) {
        setError('No organization is selected.');
        setLoading(false);
        return;
      }

      try {
        setLoading(true);
        const [customerData, productData] = await Promise.all([
          getCustomers(),
          getProducts(),
        ]);
        setCustomers(customerData.filter((c) => c.status === 'ACTIVE'));
        setProducts(productData.filter((p) => p.status === 'ACTIVE'));
      } catch (e: any) {
        setError(e?.response?.data?.message || 'Unable to load invoice setup data.');
      } finally {
        setLoading(false);
      }
    };

    load();
  }, [organizationId]);

  const selectedCustomer = useMemo(
    () => customers.find((c) => c.id === customerId) || null,
    [customers, customerId]
  );

  const lineTotals = useMemo(() => {
    return lines.map((line) => {
      const product = products.find((p) => p.id === line.productId);
      const quantity = Number(line.quantity) || 0;
      const price = product?.sellingPrice || 0;
      const discount = Math.min(Number(line.discountAmount) || 0, quantity * price);
      const base = Math.max(0, quantity * price - discount);
      const rate = line.taxRate === '' ? (product?.taxRate || 0) : Number(line.taxRate) || 0;
      let taxable = base;
      let tax = 0;
      if (line.taxTreatment === 'GST_INCLUDED') {
        taxable = rate > 0 ? base / (1 + rate / 100) : base;
        tax = base - taxable;
      } else if (line.taxTreatment === 'GST_EXTRA') {
        tax = base * rate / 100;
      }
      return { base, taxable, tax, total: line.taxTreatment === 'GST_INCLUDED' ? base : taxable + tax };
    });
  }, [lines, products]);

  const subtotal = lineTotals.reduce((s, x) => s + x.base, 0);
  const taxableTotal = lineTotals.reduce((s, x) => s + x.taxable, 0);
  const taxTotal = lineTotals.reduce((s, x) => s + x.tax, 0);
  const grandTotal = lineTotals.reduce((s, x) => s + x.total, 0);

  const updateLine = (index: number, patch: Partial<LineDraft>) => {
    setLines((current) => current.map((line, i) => i === index ? { ...line, ...patch } : line));
  };

  const selectCustomer = (value: string) => {
    setCustomerId(value);
    const customer = customers.find((c) => c.id === value);
    if (!customer) return;
    setShippingName(customer.name);
    setShippingAddress(customer.shippingAddress || customer.billingAddress || '');
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!customerId) {
      setError('Please select a customer.');
      return;
    }

    const validLines = lines.filter((line) => line.productId);
    if (!validLines.length) {
      setError('Add at least one product to the invoice.');
      return;
    }

    if (validLines.some((line) => Number(line.quantity) <= 0)) {
      setError('Quantity must be greater than zero.');
      return;
    }

    try {
      setSaving(true);

      const request: CreateInvoiceRequest = {
        invoiceDate,
        dueDate: dueDate || null,
        customerId,
        shippingName: shippingName.trim() || null,
        shippingAddress: shippingAddress.trim() || null,
        shippingState: shippingState.trim() || null,
        shippingStateCode: shippingStateCode.trim() || null,
        placeOfSupply: placeOfSupply.trim() || null,
        placeOfSupplyCode: placeOfSupplyCode.trim() || null,
        reverseCharge,
        bankName: bankName.trim() || null,
        accountNumber: accountNumber.trim() || null,
        ifscCode: ifscCode.trim() || null,
        accountType: accountType.trim() || null,
        bankBranch: bankBranch.trim() || null,
        termsAndConditions: terms.trim() || null,
        authorizedSignatoryName: signatory.trim() || null,
        items: validLines.map((line) => ({
          productId: line.productId,
          quantity: Number(line.quantity),
          discountAmount: Number(line.discountAmount) || 0,
          taxTreatment: line.taxTreatment,
          taxRate: line.taxRate === '' ? null : Number(line.taxRate),
        })),
      };

      const created = await createInvoice(request);
      const target = inWorkspace && workspaceId
        ? `/workspace/${workspaceId}/invoices/${created.id}`
        : `/invoices/${created.id}`;

      window.open(target, '_blank', 'noopener,noreferrer');
    } catch (e: any) {
      setError(e?.response?.data?.message || e?.response?.data?.error || 'Unable to create invoice.');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <div className="invoice-editor-page"><div className="invoice-editor-loading">Loading invoice setup...</div></div>;
  }

  return (
    <div className="invoice-editor-page">
      <div className="invoice-editor-header">
        <div>
          <span className="invoice-editor-eyebrow">BILLING · NEW INVOICE</span>
          <h1>Create Tax Invoice</h1>
          <p>Build a detailed GST invoice using your organization's live customers and products.</p>
        </div>
        <button type="button" className="invoice-editor-secondary" onClick={() => navigate(backPath)}>
          ← Back to Invoices
        </button>
      </div>

      {error && <div className="invoice-editor-error">{error}</div>}

      <form onSubmit={submit}>
        <section className="invoice-editor-card">
          <div className="invoice-section-heading"><div><h2>Invoice Details</h2><p>Basic invoice and buyer information.</p></div></div>
          <div className="invoice-form-grid">
            <Field label="Invoice Date"><input type="date" value={invoiceDate} onChange={(e) => setInvoiceDate(e.target.value)} required /></Field>
            <Field label="Due Date"><input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} /></Field>
            <Field label="Customer *"><select value={customerId} onChange={(e) => selectCustomer(e.target.value)} required><option value="">Select customer</option>{customers.map((c) => <option key={c.id} value={c.id}>{c.name} · {c.customerCode}</option>)}</select></Field>
            <Field label="Customer GSTIN"><input value={selectedCustomer?.taxNumber || ''} readOnly placeholder="Customer tax number" /></Field>
            <Field label="Place of Supply"><input value={placeOfSupply} onChange={(e) => setPlaceOfSupply(e.target.value)} placeholder="e.g. Telangana" /></Field>
            <Field label="Place of Supply Code"><input value={placeOfSupplyCode} onChange={(e) => setPlaceOfSupplyCode(e.target.value)} placeholder="e.g. 36" /></Field>
          </div>
          <label className="invoice-checkbox"><input type="checkbox" checked={reverseCharge} onChange={(e) => setReverseCharge(e.target.checked)} /> Reverse charge applicable</label>
        </section>

        <section className="invoice-editor-card">
          <div className="invoice-section-heading"><div><h2>Items</h2><p>Product price and default GST are sourced from Product Service.</p></div><button type="button" className="invoice-editor-secondary" onClick={() => setLines((v) => [...v, emptyLine()])}>+ Add Item</button></div>
          <div className="invoice-lines">
            {lines.map((line, index) => {
              const product = products.find((p) => p.id === line.productId);
              const total = lineTotals[index]?.total || 0;
              return (
                <div className="invoice-line" key={`${index}-${line.productId}`}>
                  <div className="invoice-line-number">{index + 1}</div>
                  <Field label="Product"><select value={line.productId} onChange={(e) => { const p = products.find((x) => x.id === e.target.value); updateLine(index, { productId: e.target.value, taxRate: p ? String(p.taxRate) : '' }); }} required><option value="">Select product</option>{products.map((p) => <option key={p.id} value={p.id}>{p.productCode} · {p.name}</option>)}</select></Field>
                  <Field label="Qty"><input type="number" min="0.001" step="0.001" value={line.quantity} onChange={(e) => updateLine(index, { quantity: e.target.value })} required /></Field>
                  <Field label="Discount"><input type="number" min="0" step="0.01" value={line.discountAmount} onChange={(e) => updateLine(index, { discountAmount: e.target.value })} /></Field>
                  <Field label="Tax Treatment"><select value={line.taxTreatment} onChange={(e) => updateLine(index, { taxTreatment: e.target.value as InvoiceTaxTreatment })}><option value="GST_EXTRA">GST Extra</option><option value="GST_INCLUDED">GST Included</option><option value="NONE">No GST</option></select></Field>
                  <Field label="GST %"><input type="number" min="0" max="100" step="0.01" value={line.taxRate} onChange={(e) => updateLine(index, { taxRate: e.target.value })} placeholder={product ? String(product.taxRate) : '0'} /></Field>
                  <div className="invoice-line-total"><span>Line Total</span><strong>{money(total)}</strong></div>
                  {lines.length > 1 && <button type="button" className="invoice-remove-line" onClick={() => setLines((v) => v.filter((_, i) => i !== index))}>Remove</button>}
                </div>
              );
            })}
          </div>
          <div className="invoice-editor-summary"><div><span>Subtotal</span><strong>{money(subtotal)}</strong></div><div><span>Taxable Value</span><strong>{money(taxableTotal)}</strong></div><div><span>Estimated GST</span><strong>{money(taxTotal)}</strong></div><div className="grand"><span>Estimated Grand Total</span><strong>{money(grandTotal)}</strong></div></div>
        </section>

        <section className="invoice-editor-card">
          <div className="invoice-section-heading"><div><h2>Shipping & Payment</h2><p>These values are stored as invoice snapshots.</p></div></div>
          <div className="invoice-form-grid">
            <Field label="Shipping Name"><input value={shippingName} onChange={(e) => setShippingName(e.target.value)} /></Field>
            <Field label="Shipping State"><input value={shippingState} onChange={(e) => setShippingState(e.target.value)} /></Field>
            <Field label="Shipping State Code"><input value={shippingStateCode} onChange={(e) => setShippingStateCode(e.target.value)} /></Field>
            <Field label="Bank Name"><input value={bankName} onChange={(e) => setBankName(e.target.value)} /></Field>
            <Field label="Account Number"><input value={accountNumber} onChange={(e) => setAccountNumber(e.target.value)} /></Field>
            <Field label="IFSC Code"><input value={ifscCode} onChange={(e) => setIfscCode(e.target.value)} /></Field>
            <Field label="Account Type"><input value={accountType} onChange={(e) => setAccountType(e.target.value)} placeholder="Current / Savings" /></Field>
            <Field label="Bank Branch"><input value={bankBranch} onChange={(e) => setBankBranch(e.target.value)} /></Field>
            <div className="invoice-field-full"><Field label="Shipping Address"><textarea rows={3} value={shippingAddress} onChange={(e) => setShippingAddress(e.target.value)} /></Field></div>
            <div className="invoice-field-full"><Field label="Terms & Conditions"><textarea rows={4} value={terms} onChange={(e) => setTerms(e.target.value)} /></Field></div>
            <Field label="Authorized Signatory"><input value={signatory} onChange={(e) => setSignatory(e.target.value)} /></Field>
          </div>
        </section>

        <div className="invoice-editor-footer-actions">
          <button type="button" className="invoice-editor-secondary" onClick={() => navigate(backPath)} disabled={saving}>Cancel</button>
          <button type="submit" className="invoice-editor-primary" disabled={saving}>{saving ? 'Creating Invoice...' : 'Create Invoice & Open'}</button>
        </div>
      </form>

      <div className="invoice-editor-source">Seller details, GST registration and invoice numbering are taken from the organization by the Invoice Service.</div>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <div className="invoice-field"><label>{label}</label>{children}</div>;
}
