import { useEffect, useState } from 'react';

import {
  getInvoices,
} from '../services/invoiceService';

import type { InvoiceResponse, InvoiceStatus } from '../types/invoice';
import './InvoiceListPage.css';

const formatCurrency = (amount: number) => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2,
  }).format(amount);
};

const formatDate = (date?: string | null) => {
  if (!date) return '-';

  return new Intl.DateTimeFormat('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
  }).format(new Date(date));
};

const getStatusClass = (status: InvoiceStatus) => {
  switch (status) {
    case 'DRAFT':
      return 'invoice-status draft';

    case 'ISSUED':
      return 'invoice-status issued';

    case 'PARTIALLY_PAID':
      return 'invoice-status partially-paid';

    case 'PAID':
      return 'invoice-status paid';

    case 'OVERDUE':
      return 'invoice-status overdue';

    case 'CANCELLED':
      return 'invoice-status cancelled';

    default:
      return 'invoice-status';
  }
};

export default function InvoiceListPage() {


  const [invoices, setInvoices] = useState<InvoiceResponse[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const loadInvoices = async () => {
    try {
      setLoading(true);
      setError('');

      const data = await getInvoices();
      setInvoices(data);
    } catch (err: any) {
      console.error('Failed to load invoices:', err);

      const message =
        err?.response?.data?.message ||
        err?.response?.data?.error ||
        'Unable to load invoices.';

      setError(message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadInvoices();
  }, []);

  const openInvoice = (invoiceId: string) => {
    window.open(
      `/workspace/invoices/${invoiceId}`,
      '_blank',
      'noopener,noreferrer'
    );
  };

  const createInvoice = () => {
    window.open(
      '/workspace/invoices/create',
      '_blank',
      'noopener,noreferrer'
    );
  };

  return (
    <div className="invoice-page">
      <div className="invoice-page-header">
        <div>
          <h1>Invoices</h1>
          <p>Manage your organization's invoices and GST billing.</p>
        </div>

        <button
          type="button"
          className="invoice-primary-button"
          onClick={createInvoice}
        >
          + Create Invoice
        </button>
      </div>

      {loading && (
        <div className="invoice-state">
          <div className="invoice-spinner" />
          <span>Loading invoices...</span>
        </div>
      )}

      {!loading && error && (
        <div className="invoice-error">
          <strong>Unable to load invoices</strong>
          <p>{error}</p>

          <button
            type="button"
            className="invoice-secondary-button"
            onClick={loadInvoices}
          >
            Try Again
          </button>
        </div>
      )}

      {!loading && !error && invoices.length === 0 && (
        <div className="invoice-empty">
          <div className="invoice-empty-icon">₹</div>

          <h2>No invoices yet</h2>

          <p>
            Create your first invoice to start managing your organization's
            billing.
          </p>

          <button
            type="button"
            className="invoice-primary-button"
            onClick={createInvoice}
          >
            Create Your First Invoice
          </button>
        </div>
      )}

      {!loading && !error && invoices.length > 0 && (
        <div className="invoice-table-container">
          <table className="invoice-table">
            <thead>
              <tr>
                <th>Invoice</th>
                <th>Customer</th>
                <th>Invoice Date</th>
                <th>Due Date</th>
                <th>Status</th>
                <th className="invoice-amount-column">Amount</th>
                <th>Action</th>
              </tr>
            </thead>

            <tbody>
              {invoices.map((invoice) => (
                <tr key={invoice.id}>
                  <td>
                    <div className="invoice-number">
                      {invoice.invoiceNumber}
                    </div>
                  </td>

                  <td>
                    <div className="invoice-customer">
                      <strong>{invoice.buyerName}</strong>

                      {invoice.buyerGstin && (
                        <small>{invoice.buyerGstin}</small>
                      )}
                    </div>
                  </td>

                  <td>{formatDate(invoice.invoiceDate)}</td>

                  <td>{formatDate(invoice.dueDate)}</td>

                  <td>
                    <span className={getStatusClass(invoice.status)}>
                      {invoice.status.replace('_', ' ')}
                    </span>
                  </td>

                  <td className="invoice-amount">
                    {formatCurrency(invoice.grandTotal)}
                  </td>

                  <td>
                    <button
                      type="button"
                      className="invoice-view-button"
                      onClick={() => openInvoice(invoice.id)}
                    >
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}