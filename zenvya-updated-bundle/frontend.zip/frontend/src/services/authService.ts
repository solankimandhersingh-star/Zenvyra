import api from './api';

export interface LoginUser {
  id: string;
  organizationId: string | null;
  username: string;
  firstName: string;
  lastName: string | null;
  email: string | null;
  mobile: string | null;
  role: string;
  status: string;
}

interface LoginResponse {
  accessToken: string;
  refreshToken: string;
  tokenType: string;
  expiresIn: number;
  user: LoginUser;
}

export const login = async (
  username: string,
  password: string,
  organizationCode?: string
): Promise<LoginUser> => {
  const response = await api.post<LoginResponse>('/users/login', {
    username,
    password,
    organizationCode: organizationCode?.trim() || null,
  });

  // Store authentication only for this browser tab
  sessionStorage.setItem(
    'zenvya_access_token',
    response.data.accessToken
  );

  sessionStorage.setItem(
    'zenvya_refresh_token',
    response.data.refreshToken
  );

  sessionStorage.setItem(
    'zenvya_user',
    JSON.stringify(response.data.user)
  );

  // Remove any old localStorage authentication
  localStorage.removeItem('zenvya_access_token');
  localStorage.removeItem('zenvya_refresh_token');
  localStorage.removeItem('zenvya_user');

  return response.data.user;
};

export const getStoredUser = (): LoginUser | null => {
  const storedUser = sessionStorage.getItem('zenvya_user');

  if (!storedUser) {
    return null;
  }

  try {
    return JSON.parse(storedUser) as LoginUser;
  } catch {
    sessionStorage.removeItem('zenvya_user');
    return null;
  }
};

export const logout = (): void => {
  sessionStorage.removeItem('zenvya_access_token');
  sessionStorage.removeItem('zenvya_refresh_token');
  sessionStorage.removeItem('zenvya_user');

  // Also clear old localStorage values
  localStorage.removeItem('zenvya_access_token');
  localStorage.removeItem('zenvya_refresh_token');
  localStorage.removeItem('zenvya_user');
};