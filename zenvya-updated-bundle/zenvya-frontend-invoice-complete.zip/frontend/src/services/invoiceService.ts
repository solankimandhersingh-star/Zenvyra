import api from './api';
import type {
  CreateInvoiceRequest,
  InvoiceResponse,
} from '../types/invoice';

export const getInvoices = async (): Promise<InvoiceResponse[]> => {
  const response = await api.get<InvoiceResponse[]>('/invoices');
  return response.data;
};

export const getInvoiceById = async (
  invoiceId: string
): Promise<InvoiceResponse> => {
  const response = await api.get<InvoiceResponse>(
    `/invoices/${invoiceId}`
  );

  return response.data;
};

export const createInvoice = async (
  request: CreateInvoiceRequest
): Promise<InvoiceResponse> => {
  const response = await api.post<InvoiceResponse>(
    '/invoices',
    request
  );

  return response.data;
};