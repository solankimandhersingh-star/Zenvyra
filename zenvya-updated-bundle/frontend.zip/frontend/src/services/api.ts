import axios, {
  type AxiosError,
  type InternalAxiosRequestConfig,
} from 'axios';

const API_BASE_URL = 'http://localhost:8080/api';

const api = axios.create({
  baseURL: API_BASE_URL,
});

const refreshClient = axios.create({
  baseURL: API_BASE_URL,
});

let refreshPromise: Promise<string | null> | null = null;

const isAuthEndpoint = (url?: string) =>
  !!url &&
  (url.includes('/users/login') || url.includes('/users/refresh'));

const clearAuthStorage = () => {
  // Current tab session
  sessionStorage.removeItem('zenvya_access_token');
  sessionStorage.removeItem('zenvya_refresh_token');
  sessionStorage.removeItem('zenvya_user');

  // Remove old localStorage authentication if it exists
  localStorage.removeItem('zenvya_access_token');
  localStorage.removeItem('zenvya_refresh_token');
  localStorage.removeItem('zenvya_user');
};

const refreshAccessToken = async (): Promise<string | null> => {
  const refreshToken = sessionStorage.getItem('zenvya_refresh_token');

  if (!refreshToken) {
    return null;
  }

  if (!refreshPromise) {
    refreshPromise = refreshClient
      .post('/users/refresh', { refreshToken })
      .then((response) => {
        const {
          accessToken,
          refreshToken: rotatedRefreshToken,
          user,
        } = response.data;

        sessionStorage.setItem(
          'zenvya_access_token',
          accessToken
        );

        if (rotatedRefreshToken) {
          sessionStorage.setItem(
            'zenvya_refresh_token',
            rotatedRefreshToken
          );
        }

        if (user) {
          sessionStorage.setItem(
            'zenvya_user',
            JSON.stringify(user)
          );
        }

        return accessToken as string;
      })
      .catch((error) => {
        console.error('Token refresh failed:', error);
        return null;
      })
      .finally(() => {
        refreshPromise = null;
      });
  }

  return refreshPromise;
};

/**
 * Add authentication and selected organization context.
 */
api.interceptors.request.use((config) => {
  const token = sessionStorage.getItem('zenvya_access_token');

  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }

  /**
   * Super Admin organization workspace.
   *
   * Example:
   * /workspace/7fdbd2ba-9a13-4bfb-8ef2-28d5196a17e3/invoices
   *
   * The backend will only honor this header for SUPER_ADMIN.
   * ORG_ADMIN / ORG_USER continue using organizationId from JWT.
   */
  const match = window.location.pathname.match(
    /^\/workspace\/([^/]+)/
  );

  if (match?.[1]) {
    config.headers['X-Organization-Id'] = match[1];
  }

  return config;
});

api.interceptors.response.use(
  (response) => response,

  async (error: AxiosError) => {
    const originalRequest = error.config as
      | (InternalAxiosRequestConfig & { _retry?: boolean })
      | undefined;

    console.error(
      'API ERROR:',
      originalRequest?.method,
      originalRequest?.url,
      error.response?.status,
      error.response?.data
    );

    /**
     * Access token expired.
     * Try to refresh it once.
     */
    if (
      error.response?.status === 401 &&
      originalRequest &&
      !originalRequest._retry &&
      !isAuthEndpoint(originalRequest.url)
    ) {
      originalRequest._retry = true;

      const newAccessToken = await refreshAccessToken();

      if (newAccessToken) {
        originalRequest.headers.Authorization =
          `Bearer ${newAccessToken}`;

        return api(originalRequest);
      }
    }

    /**
     * Login / refresh authentication failed.
     */
    if (
      error.response?.status === 401 &&
      isAuthEndpoint(originalRequest?.url)
    ) {
      clearAuthStorage();
    }

    /**
     * Refresh failed or authentication is no longer valid.
     */
    if (
      error.response?.status === 401 &&
      (!originalRequest || originalRequest._retry)
    ) {
      clearAuthStorage();

      if (window.location.pathname !== '/login') {
        window.location.href = '/login';
      }
    }

    return Promise.reject(error);
  }
);

export default api;